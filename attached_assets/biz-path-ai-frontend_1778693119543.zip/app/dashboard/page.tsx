'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ArrowRight, TrendingUp, DollarSign, Zap, BarChart3 } from 'lucide-react'

type Recommendation = {
  id: string
  name: string
  matchPercentage: number
  startupCost: string
  riskLevel: 'Low' | 'Medium' | 'High'
  profitPotential: 'Low' | 'Medium' | 'High'
  readinessScore: number
  description: string
  icon: string
}

const mockRecommendations: Recommendation[] = [
  {
    id: '1',
    name: 'Freelance Writing',
    matchPercentage: 92,
    startupCost: '$500 - $2,000',
    riskLevel: 'Low',
    profitPotential: 'Medium',
    readinessScore: 85,
    description: 'Leverage your communication skills to build a writing business.',
    icon: '✍️'
  },
  {
    id: '2',
    name: 'Digital Marketing Agency',
    matchPercentage: 88,
    startupCost: '$2,000 - $8,000',
    riskLevel: 'Medium',
    profitPotential: 'High',
    readinessScore: 72,
    description: 'Help businesses grow their online presence.',
    icon: '📱'
  },
  {
    id: '3',
    name: 'Photography Services',
    matchPercentage: 85,
    startupCost: '$1,000 - $5,000',
    riskLevel: 'Low',
    profitPotential: 'Medium',
    readinessScore: 78,
    description: 'Offer photography for events, products, and more.',
    icon: '📸'
  },
  {
    id: '4',
    name: 'Online Tutoring Platform',
    matchPercentage: 82,
    startupCost: '$500 - $3,000',
    riskLevel: 'Low',
    profitPotential: 'Medium',
    readinessScore: 80,
    description: 'Teach students online in your area of expertise.',
    icon: '📚'
  },
  {
    id: '5',
    name: 'E-commerce Store',
    matchPercentage: 78,
    startupCost: '$5,000 - $15,000',
    riskLevel: 'Medium',
    profitPotential: 'High',
    readinessScore: 68,
    description: 'Start selling products online.',
    icon: '🛍️'
  },
  {
    id: '6',
    name: 'Social Media Management',
    matchPercentage: 75,
    startupCost: '$1,000 - $4,000',
    riskLevel: 'Low',
    profitPotential: 'Medium',
    readinessScore: 70,
    description: 'Manage social media for small businesses.',
    icon: '📊'
  }
]

export default function DashboardPage() {
  const [sortBy, setSortBy] = useState<'match' | 'cost' | 'readiness'>('match')
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const sortedRecommendations = [...mockRecommendations].sort((a, b) => {
    switch (sortBy) {
      case 'match':
        return b.matchPercentage - a.matchPercentage
      case 'cost':
        return a.startupCost.localeCompare(b.startupCost)
      case 'readiness':
        return b.readinessScore - a.readinessScore
      default:
        return 0
    }
  })

  if (!mounted) return null

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Header */}
        <div className="mb-12">
          <Link href="/" className="text-sm text-muted-foreground hover:text-foreground transition-colors mb-6 inline-flex items-center gap-2">
            ← Back to Home
          </Link>
          <h1 className="text-4xl font-bold mb-2">Your Business Recommendations</h1>
          <p className="text-muted-foreground">Based on your assessment, here are businesses you can realistically start.</p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-12">
          {[
            { label: 'Overall Readiness', value: '82%', icon: Zap },
            { label: 'Matching Opportunities', value: '12+', icon: TrendingUp },
            { label: 'Avg. Startup Cost', value: '$4,500', icon: DollarSign },
            { label: 'Risk Assessment', value: 'Medium', icon: BarChart3 }
          ].map((card, index) => {
            const Icon = card.icon
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="p-6 border-border">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">{card.label}</p>
                      <p className="text-2xl font-bold">{card.value}</p>
                    </div>
                    <Icon className="w-8 h-8 text-primary opacity-50" />
                  </div>
                </Card>
              </motion.div>
            )
          })}
        </div>

        {/* Sort Options */}
        <div className="flex gap-3 mb-8 flex-wrap">
          <span className="text-sm text-muted-foreground">Sort by:</span>
          {[
            { value: 'match' as const, label: 'Best Match' },
            { value: 'cost' as const, label: 'Lowest Cost' },
            { value: 'readiness' as const, label: 'Readiness Score' }
          ].map(option => (
            <button
              key={option.value}
              onClick={() => setSortBy(option.value)}
              className={`px-4 py-2 rounded-lg transition-all text-sm font-medium ${
                sortBy === option.value
                  ? 'bg-primary text-white'
                  : 'bg-card border border-border hover:border-primary/50'
              }`}
            >
              {option.label}
            </button>
          ))}
        </div>

        {/* Recommendations Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-12">
          {sortedRecommendations.map((rec, index) => (
            <motion.div
              key={rec.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Link href={`/business/${rec.id}`}>
                <Card className="p-6 border-border hover:border-primary/50 transition-all hover:shadow-lg hover:shadow-primary/10 cursor-pointer h-full">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-start gap-4">
                      <div className="text-4xl">{rec.icon}</div>
                      <div>
                        <h3 className="text-xl font-semibold">{rec.name}</h3>
                        <p className="text-sm text-muted-foreground">{rec.description}</p>
                      </div>
                    </div>
                  </div>

                  {/* Match Percentage Circle */}
                  <div className="flex items-center gap-4 mb-6 pb-6 border-b border-border">
                    <div className="relative w-16 h-16">
                      <svg className="w-16 h-16 transform -rotate-90">
                        <circle cx="32" cy="32" r="28" fill="none" stroke="#2a2a3e" strokeWidth="4" />
                        <motion.circle
                          cx="32"
                          cy="32"
                          r="28"
                          fill="none"
                          stroke="url(#gradient)"
                          strokeWidth="4"
                          strokeDasharray={`${2 * Math.PI * 28}`}
                          strokeDashoffset={`${2 * Math.PI * 28 * (1 - rec.matchPercentage / 100)}`}
                          initial={{ strokeDashoffset: 2 * Math.PI * 28 }}
                          animate={{ strokeDashoffset: `${2 * Math.PI * 28 * (1 - rec.matchPercentage / 100)}` }}
                          transition={{ delay: 0.2, duration: 1 }}
                        />
                        <defs>
                          <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stopColor="#6366f1" />
                            <stop offset="100%" stopColor="#8b5cf6" />
                          </linearGradient>
                        </defs>
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className="text-sm font-bold">{rec.matchPercentage}%</span>
                      </div>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Match Score</p>
                      <p className="font-semibold">Perfect Fit</p>
                    </div>
                  </div>

                  {/* Details Grid */}
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Startup Cost</p>
                      <p className="font-semibold text-sm">{rec.startupCost}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Risk Level</p>
                      <Badge variant={rec.riskLevel === 'Low' ? 'default' : rec.riskLevel === 'Medium' ? 'secondary' : 'destructive'}>
                        {rec.riskLevel}
                      </Badge>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Readiness Score</p>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-2 bg-card rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-primary to-accent"
                            style={{ width: `${rec.readinessScore}%` }}
                          />
                        </div>
                        <span className="text-sm font-semibold">{rec.readinessScore}%</span>
                      </div>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Profit Potential</p>
                      <Badge variant={rec.profitPotential === 'High' ? 'default' : 'secondary'}>
                        {rec.profitPotential}
                      </Badge>
                    </div>
                  </div>

                  {/* CTA */}
                  <Button className="w-full bg-primary hover:bg-primary/90 flex items-center justify-center gap-2">
                    View Details
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </Card>
              </Link>
            </motion.div>
          ))}
        </div>

        {/* AI Coach CTA */}
        <Card className="p-8 border-border bg-gradient-to-r from-primary/10 to-accent/10 text-center">
          <h3 className="text-2xl font-bold mb-3">Need Help Deciding?</h3>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            Our AI Business Coach can answer your questions and help you explore these opportunities in more detail.
          </p>
          <Button asChild size="lg" className="bg-primary hover:bg-primary/90">
            <Link href="/coach">Chat with AI Coach</Link>
          </Button>
        </Card>
      </div>
    </div>
  )
}
