'use client'

import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ComposedChart } from 'recharts'
import { Download, BookOpen, RefreshCw, TrendingUp, Zap, Target } from 'lucide-react'
import Link from 'next/link'

const materialData = [
  { phase: 'Phase 1', initial: 10000, adjusted: 9800, label: 'Month 1' },
  { phase: 'Phase 2', initial: 15000, adjusted: 14500, label: 'Month 3' },
  { phase: 'Phase 3', initial: 25000, adjusted: 23800, label: 'Month 6' },
]

const growthData = [
  { month: 'M1', revenue: 2000 },
  { month: 'M2', revenue: 3500 },
  { month: 'M3', revenue: 5200 },
  { month: 'M4', revenue: 7800 },
  { month: 'M5', revenue: 11500 },
  { month: 'M6', revenue: 15800 },
]

const skillGaps = [
  { skill: 'Business Planning', gap: 20, you: 60 },
  { skill: 'Customer Service', gap: 15, you: 75 },
  { skill: 'Financial Management', gap: 35, you: 45 },
  { skill: 'Digital Marketing', gap: 10, you: 80 },
]

const opportunities = [
  {
    title: 'Coffee Shop Business',
    readiness: 92,
    capital: 'ETB 50,000 - 100,000',
    timeline: '3-6 months',
    skills: ['Customer Service', 'Management', 'Sales'],
    viability: 'High',
    market: 'Growing'
  },
  {
    title: 'Digital Marketing Agency',
    readiness: 88,
    capital: 'ETB 15,000 - 30,000',
    timeline: '2-3 months',
    skills: ['Marketing', 'Coding', 'Sales'],
    viability: 'Very High',
    market: 'Booming'
  },
  {
    title: 'Content Creation Platform',
    readiness: 85,
    capital: 'ETB 5,000 - 15,000',
    timeline: '1-2 months',
    skills: ['Writing', 'Design', 'Digital Marketing'],
    viability: 'High',
    market: 'Growing'
  },
  {
    title: 'E-Commerce Store',
    readiness: 82,
    capital: 'ETB 20,000 - 50,000',
    timeline: '2-3 months',
    skills: ['Sales', 'Design', 'Customer Service'],
    viability: 'High',
    market: 'Growing'
  },
  {
    title: 'Freelance Coding Services',
    readiness: 90,
    capital: 'ETB 2,000 - 5,000',
    timeline: 'Immediate',
    skills: ['Coding', 'Customer Service', 'Sales'],
    viability: 'Very High',
    market: 'Very Hot'
  },
  {
    title: 'Event Planning Services',
    readiness: 78,
    capital: 'ETB 10,000 - 25,000',
    timeline: '2-3 months',
    skills: ['Management', 'Sales', 'Customer Service'],
    viability: 'Medium',
    market: 'Growing'
  }
]

export default function ResultsPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      <div className="flex-1 px-4 py-12 md:py-16 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-12">
            <div className="inline-block px-4 py-2 rounded-full border border-primary/30 bg-primary/10 mb-6">
              <p className="text-sm font-medium text-primary flex items-center gap-2">
                <Zap className="w-4 h-4" />
                Your Personalized Roadmap
              </p>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Turn Your Degree Into a Dynasty
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl">
              Based on your profile, we&apos;ve identified 6 high-viability business opportunities perfectly suited to your skills, budget, and location.
            </p>
            
            {/* Inflation Note */}
            <div className="mt-6 inline-block px-4 py-2 rounded-lg border border-yellow-500/30 bg-yellow-500/5">
              <p className="text-sm text-yellow-600">📊 All figures adjusted for April 2026 inflation</p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 mb-12">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-white flex items-center gap-2">
              <Download className="w-4 h-4" />
              Export as PDF
            </Button>
            <Button size="lg" variant="outline" className="flex items-center gap-2">
              <BookOpen className="w-4 h-4" />
              Save Roadmap
            </Button>
            <Button size="lg" variant="outline" asChild className="flex items-center gap-2">
              <Link href="/assessment">
                <RefreshCw className="w-4 h-4" />
                New Assessment
              </Link>
            </Button>
          </div>

          {/* 3-Column Grid: Material Ledger, Growth Ladder, Skills Analysis */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-12">
            {/* Material Ledger */}
            <Card className="glass p-6 border-primary/20 lg:col-span-1">
              <div className="mb-6">
                <h2 className="text-xl font-bold flex items-center gap-2">
                  <Target className="w-5 h-5 text-primary" />
                  Capital Roadmap
                </h2>
                <p className="text-sm text-muted-foreground mt-1">
                  Inflation-adjusted capital needs by phase
                </p>
              </div>

              <div className="space-y-3">
                {materialData.map((data, i) => (
                  <div key={i} className="bg-background/50 rounded-lg p-3 border border-border">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <p className="font-semibold text-sm">{data.phase}</p>
                        <p className="text-xs text-muted-foreground">{data.label}</p>
                      </div>
                      <Badge className="bg-primary/20 text-primary border-primary/50">
                        {(((data.initial - data.adjusted) / data.initial) * 100).toFixed(0)}% saved
                      </Badge>
                    </div>
                    <div className="flex gap-2 text-xs">
                      <div>
                        <p className="text-muted-foreground">Before</p>
                        <p className="font-semibold text-primary">ETB {data.initial.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">After</p>
                        <p className="font-semibold text-primary">ETB {data.adjusted.toLocaleString()}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Growth Ladder */}
            <Card className="glass p-6 border-primary/20 lg:col-span-1">
              <div className="mb-6">
                <h2 className="text-xl font-bold flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-primary" />
                  6-Month Revenue Projection
                </h2>
                <p className="text-sm text-muted-foreground mt-1">
                  Expected growth trajectory
                </p>
              </div>

              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={growthData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(16,185,129,0.1)" />
                  <XAxis dataKey="month" stroke="rgb(160,160,160)" style={{ fontSize: '12px' }} />
                  <YAxis stroke="rgb(160,160,160)" style={{ fontSize: '12px' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(26,26,26,0.9)',
                      border: '1px solid rgba(16,185,129,0.3)',
                      borderRadius: '8px'
                    }}
                    formatter={(value) => [`ETB ${value.toLocaleString()}`, 'Revenue']}
                  />
                  <Line
                    type="monotone"
                    dataKey="revenue"
                    stroke="#10b981"
                    dot={{ fill: '#10b981', r: 4 }}
                    activeDot={{ r: 6 }}
                    strokeWidth={2}
                  />
                </LineChart>
              </ResponsiveContainer>
            </Card>

            {/* Skills Analysis */}
            <Card className="glass p-6 border-primary/20 lg:col-span-1">
              <div className="mb-6">
                <h2 className="text-xl font-bold flex items-center gap-2">
                  <Zap className="w-5 h-5 text-primary" />
                  Skills Analysis
                </h2>
                <p className="text-sm text-muted-foreground mt-1">
                  Your gaps vs. requirements
                </p>
              </div>

              <div className="space-y-3">
                {skillGaps.map((item, i) => (
                  <div key={i} className="bg-background/50 rounded-lg p-3 border border-border">
                    <div className="flex justify-between items-center mb-2">
                      <p className="text-sm font-semibold">{item.skill}</p>
                      <span className="text-xs text-primary font-semibold">{item.you}%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary"
                        style={{ width: `${item.you}%` }}
                      />
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      Gap: {item.gap}% | Training needed
                    </p>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Recommended Opportunities */}
          <div className="mb-12">
            <div className="mb-8">
              <h2 className="text-3xl font-bold mb-2">6 Recommended Opportunities</h2>
              <p className="text-muted-foreground">
                Ranked by readiness score and market viability in your region
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {opportunities.map((opp, i) => (
                <Card key={i} className="glass border-primary/20 hover:border-primary/40 transition-all duration-300 overflow-hidden group">
                  <div className="p-6">
                    {/* Header with Readiness */}
                    <div className="flex justify-between items-start mb-4">
                      <h3 className="text-lg font-bold flex-1">{opp.title}</h3>
                      <div className="text-right ml-4">
                        <p className="text-xs text-muted-foreground">Readiness</p>
                        <p className="text-2xl font-bold text-primary">{opp.readiness}%</p>
                      </div>
                    </div>

                    {/* Metrics */}
                    <div className="space-y-2 mb-4 pb-4 border-b border-border">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Capital</span>
                        <span className="font-semibold text-primary">{opp.capital}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Timeline</span>
                        <span className="font-semibold">{opp.timeline}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Viability</span>
                        <Badge className={`${
                          opp.viability === 'Very High'
                            ? 'bg-green-500/20 text-green-400 border-green-500/50'
                            : 'bg-primary/20 text-primary border-primary/50'
                        }`}>
                          {opp.viability}
                        </Badge>
                      </div>
                    </div>

                    {/* Skills Required */}
                    <div className="mb-4">
                      <p className="text-xs font-semibold text-muted-foreground mb-2">Required Skills</p>
                      <div className="flex flex-wrap gap-2">
                        {opp.skills.map((skill, j) => (
                          <Badge key={j} variant="secondary" className="bg-primary/10 text-primary border-primary/30 text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {/* Market Status */}
                    <div className="mb-4 p-3 rounded-lg bg-background/50 border border-border">
                      <p className="text-xs text-muted-foreground mb-1">Market Status</p>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-primary"></div>
                        <p className="text-sm font-semibold">{opp.market}</p>
                      </div>
                    </div>

                    {/* Action Button */}
                    <Button className="w-full bg-primary hover:bg-primary/90 text-white group-hover:shadow-md group-hover:shadow-primary/20 transition-all">
                      Explore This Business
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          {/* CTA Section */}
          <Card className="glass border-primary/20 p-12 text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Start Your Journey?</h2>
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              Get detailed implementation guides, market analysis, and step-by-step roadmaps for any of these businesses.
            </p>
            <div className="flex gap-4 justify-center">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-white">
                Start Free Coach Session
              </Button>
              <Button size="lg" variant="outline">
                Download Full Report
              </Button>
            </div>
          </Card>
        </div>
      </div>
      <Footer />
    </div>
  )
}
