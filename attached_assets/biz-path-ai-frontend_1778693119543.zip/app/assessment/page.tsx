'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Slider } from '@/components/ui/slider'
import { Badge } from '@/components/ui/badge'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { ArrowRight, ArrowLeft, Zap, TrendingUp } from 'lucide-react'
import Link from 'next/link'

const SKILLS = [
  'Digital Marketing', 'Coding', 'Writing', 'Design', 'Sales',
  'Customer Service', 'Project Management', 'Data Analysis',
  'Video Production', 'Photography', 'Teaching', 'Accounting'
]

const PASSIONS = [
  'Technology', 'Business', 'Education', 'Health', 'Environment',
  'Fashion', 'Food', 'Entertainment', 'Travel', 'Finance',
  'Sports', 'Arts & Culture'
]

const COUNTRIES = [
  'Ethiopia', 'Kenya', 'Nigeria', 'South Africa', 'Rwanda',
  'Uganda', 'Tanzania', 'Ghana', 'Senegal', 'Other'
]

const EDUCATION_LEVELS = [
  'No Formal Degree / Hustle Mode',
  'High School',
  'Diploma',
  'Bachelor\'s Degree',
  'Master\'s Degree',
  'PhD'
]

export default function AssessmentPage() {
  const [currentStep, setCurrentStep] = useState(0)
  const [capital, setCapital] = useState(5000)
  const [selectedCountry, setSelectedCountry] = useState('Ethiopia')
  const [selectedEducation, setSelectedEducation] = useState('Bachelor\'s Degree')
  const [selectedSkills, setSelectedSkills] = useState<string[]>([])
  const [selectedPassions, setSelectedPassions] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(false)

  const toggleSkill = (skill: string) => {
    setSelectedSkills(prev =>
      prev.includes(skill) ? prev.filter(s => s !== skill) : [...prev, skill]
    )
  }

  const togglePassion = (passion: string) => {
    setSelectedPassions(prev =>
      prev.includes(passion) ? prev.filter(p => p !== passion) : [...prev, passion]
    )
  }

  const handleNext = () => {
    if (currentStep === 3) {
      setIsLoading(true)
      setTimeout(() => {
        window.location.href = '/results'
      }, 3000)
    } else {
      setCurrentStep(currentStep + 1)
    }
  }

  const handlePrev = () => {
    if (currentStep > 0) setCurrentStep(currentStep - 1)
  }

  const exchangeRate = 50
  const capitalInUSD = Math.round(capital / exchangeRate)

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      <div className="flex-1 px-4 py-12 md:py-16 lg:px-8">
        <div className="max-w-3xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="inline-block px-4 py-2 rounded-full border border-primary/30 bg-primary/10 mb-6">
              <p className="text-sm font-medium text-primary flex items-center gap-2">
                <Zap className="w-4 h-4" />
                AI Business Assessment
              </p>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Build Your Business Roadmap
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Answer a few questions to discover businesses you can start with your current resources.
            </p>
          </div>

          {/* Progress Indicator */}
          <div className="mb-8">
            <div className="flex justify-between mb-3">
              {[0, 1, 2, 3].map((step) => (
                <div key={step} className="flex-1">
                  <div
                    className={`h-2 mx-1 rounded-full transition-all duration-300 ${
                      step <= currentStep
                        ? 'bg-primary shadow-md shadow-primary/50'
                        : 'bg-muted'
                    }`}
                  />
                </div>
              ))}
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">
                Step {currentStep + 1} of 4
              </span>
              <span className="text-primary font-semibold">
                {['Capital', 'Background', 'Skills & Passion', 'Review'][currentStep]}
              </span>
            </div>
          </div>

          {/* Steps */}
          <Card className="glass p-8 min-h-96 mb-8 border-primary/20">
            {/* Step 1: Capital */}
            {currentStep === 0 && (
              <div className="space-y-8">
                <div>
                  <h2 className="text-3xl font-bold mb-2">What capital do you have?</h2>
                  <p className="text-muted-foreground text-lg">
                    This helps us recommend businesses you can actually start right now.
                  </p>
                </div>

                <div className="space-y-6">
                  <div className="bg-card p-6 rounded-lg border border-primary/30">
                    <div className="text-center mb-6">
                      <p className="text-sm text-muted-foreground mb-2">Estimated Amount</p>
                      <div className="flex items-baseline justify-center gap-2">
                        <span className="text-5xl font-bold text-primary">
                          ETB {capital.toLocaleString()}
                        </span>
                        <span className="text-2xl text-muted-foreground">
                          (≈ ${capitalInUSD})
                        </span>
                      </div>
                    </div>

                    <Slider
                      value={[capital]}
                      onValueChange={(value) => setCapital(value[0])}
                      min={500}
                      max={500000}
                      step={500}
                      className="w-full mb-4"
                    />

                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>ETB 500</span>
                      <span>ETB 500,000+</span>
                    </div>
                  </div>

                  <div className="bg-background/50 border border-border rounded-lg p-4 text-sm text-muted-foreground">
                    <p><strong>💡 Tip:</strong> Include cash savings, family support, loans you can secure, or inventory you already own.</p>
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: Background */}
            {currentStep === 1 && (
              <div className="space-y-8">
                <div>
                  <h2 className="text-3xl font-bold mb-2">Tell us about yourself</h2>
                  <p className="text-muted-foreground text-lg">
                    Your background helps us match you with realistic opportunities.
                  </p>
                </div>

                <div className="space-y-6">
                  {/* Country Selection */}
                  <div>
                    <label className="block text-sm font-semibold mb-3">
                      Country / Region
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {COUNTRIES.map((country) => (
                        <button
                          key={country}
                          onClick={() => setSelectedCountry(country)}
                          className={`px-4 py-3 rounded-lg border transition-all ${
                            selectedCountry === country
                              ? 'border-primary bg-primary/10 text-primary font-semibold shadow-md shadow-primary/20'
                              : 'border-border hover:border-primary/50 text-muted-foreground hover:text-foreground'
                          }`}
                        >
                          {country}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Education Level */}
                  <div>
                    <label className="block text-sm font-semibold mb-3">
                      Education / Experience Level
                    </label>
                    <div className="space-y-2">
                      {EDUCATION_LEVELS.map((level) => (
                        <button
                          key={level}
                          onClick={() => setSelectedEducation(level)}
                          className={`w-full px-4 py-3 rounded-lg border text-left transition-all ${
                            selectedEducation === level
                              ? 'border-primary bg-primary/10 text-primary font-semibold shadow-md shadow-primary/20'
                              : 'border-border hover:border-primary/50 text-foreground'
                          }`}
                        >
                          {level}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step 3: Skills & Passions */}
            {currentStep === 2 && (
              <div className="space-y-8">
                <div>
                  <h2 className="text-3xl font-bold mb-2">Your skills & passions</h2>
                  <p className="text-muted-foreground text-lg">
                    Select what you&apos;re good at and what you love doing.
                  </p>
                </div>

                <div className="space-y-6">
                  {/* Skills */}
                  <div>
                    <label className="block text-sm font-semibold mb-3">
                      Skills (Select at least 2)
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {SKILLS.map((skill) => (
                        <button
                          key={skill}
                          onClick={() => toggleSkill(skill)}
                          className={`px-4 py-2 rounded-full border transition-all ${
                            selectedSkills.includes(skill)
                              ? 'border-primary bg-primary/20 text-primary font-semibold shadow-md shadow-primary/30'
                              : 'border-border hover:border-primary/50 text-muted-foreground hover:text-foreground'
                          }`}
                        >
                          {skill}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Passions */}
                  <div>
                    <label className="block text-sm font-semibold mb-3">
                      Passions (Select at least 2)
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {PASSIONS.map((passion) => (
                        <button
                          key={passion}
                          onClick={() => togglePassion(passion)}
                          className={`px-4 py-2 rounded-full border transition-all ${
                            selectedPassions.includes(passion)
                              ? 'border-primary bg-primary/20 text-primary font-semibold shadow-md shadow-primary/30'
                              : 'border-border hover:border-primary/50 text-muted-foreground hover:text-foreground'
                          }`}
                        >
                          {passion}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step 4: Review & Loading */}
            {currentStep === 3 && (
              <div className="space-y-8">
                {!isLoading ? (
                  <>
                    <div>
                      <h2 className="text-3xl font-bold mb-2">Review your profile</h2>
                      <p className="text-muted-foreground text-lg">
                        Let&apos;s make sure everything looks good before we scan the market.
                      </p>
                    </div>

                    <div className="space-y-4">
                      <div className="bg-background/50 border border-border rounded-lg p-4">
                        <p className="text-sm text-muted-foreground mb-1">Capital Available</p>
                        <p className="text-xl font-semibold text-primary">
                          ETB {capital.toLocaleString()} (≈ ${capitalInUSD})
                        </p>
                      </div>

                      <div className="bg-background/50 border border-border rounded-lg p-4">
                        <p className="text-sm text-muted-foreground mb-2">Background</p>
                        <p className="font-semibold">{selectedCountry}</p>
                        <p className="text-sm text-muted-foreground">{selectedEducation}</p>
                      </div>

                      <div className="bg-background/50 border border-border rounded-lg p-4">
                        <p className="text-sm text-muted-foreground mb-2">Skills Selected</p>
                        <div className="flex flex-wrap gap-2">
                          {selectedSkills.map((skill) => (
                            <Badge key={skill} variant="secondary" className="bg-primary/20 text-primary border-primary/50">
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div className="bg-background/50 border border-border rounded-lg p-4">
                        <p className="text-sm text-muted-foreground mb-2">Passions Selected</p>
                        <div className="flex flex-wrap gap-2">
                          {selectedPassions.map((passion) => (
                            <Badge key={passion} variant="secondary" className="bg-primary/20 text-primary border-primary/50">
                              {passion}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="py-12 text-center space-y-6">
                    <div className="flex justify-center mb-6">
                      <div className="relative w-16 h-16">
                        <div className="absolute inset-0 rounded-full border-4 border-muted animate-spin border-t-primary"></div>
                        <div className="absolute inset-0 flex items-center justify-center">
                          <TrendingUp className="w-8 h-8 text-primary animate-pulse" />
                        </div>
                      </div>
                    </div>
                    <h3 className="text-2xl font-bold">Scanning Ethiopian Market Opportunities...</h3>
                    <p className="text-muted-foreground">
                      Our AI is analyzing thousands of businesses to find your perfect match.
                    </p>
                    <div className="space-y-2 pt-4">
                      {['Matching capital constraints', 'Evaluating skill requirements', 'Checking market trends', 'Computing readiness scores'].map((item, i) => (
                        <div key={i} className="flex items-center gap-3 justify-center">
                          <div className={`w-2 h-2 rounded-full ${i === 0 ? 'bg-primary' : 'bg-muted'}`}></div>
                          <span className="text-sm text-muted-foreground">{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </Card>

          {/* Navigation Buttons */}
          <div className="flex gap-4 justify-between">
            <Button
              onClick={handlePrev}
              variant="outline"
              size="lg"
              disabled={currentStep === 0}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Previous
            </Button>

            <Button
              onClick={handleNext}
              size="lg"
              disabled={
                (currentStep === 2 && (selectedSkills.length < 2 || selectedPassions.length < 2)) ||
                isLoading
              }
              className="button-glow flex items-center gap-2 bg-primary hover:bg-primary/90 text-white"
            >
              {currentStep === 3 && !isLoading ? 'Get Results' : 'Next'}
              <ArrowRight className="w-4 h-4" />
            </Button>
          </div>

          {/* Skip Link */}
          <div className="text-center mt-6">
            <Link href="/results" className="text-sm text-muted-foreground hover:text-primary transition-colors">
              Skip to sample results →
            </Link>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
}
