'use client'

import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { Send, Zap, Lightbulb, HelpCircle, ArrowRight, Loader } from 'lucide-react'

type Message = {
  id: string
  type: 'user' | 'coach'
  content: string
  timestamp: Date
}

const mockResponses: Record<string, string> = {
  'how': 'Great question! To get started with freelance writing, I recommend:\n\n1. Build a strong portfolio with 3-5 sample pieces\n2. Create profiles on platforms like Upwork and Fiverr\n3. Start by bidding on smaller projects to build experience\n4. Focus on getting great testimonials from early clients\n\nWould you like help with any of these steps?',
  'skill': 'Based on your profile, I\'d recommend focusing on:\n\n- SEO Writing: This skill is in high demand and can increase your rates by 30-50%\n- Technical Writing: Great for specialized clients\n- Copywriting: Essential for marketing and sales content\n\nI can recommend free courses for any of these. Which interests you most?',
  'cost': 'For freelance writing, your startup costs are minimal:\n\n- Portfolio website (free with Wix or WordPress.com)\n- Writing tools (free options like Grammarly Basic)\n- Laptop (you already have)\n- No inventory needed\n\nTotal minimum: $0-200. Your profit margins start at 50%+ for most projects.',
  'market': 'The writing market is booming! Current trends:\n\n- AI-powered content marketing is growing\n- Video scripts are in high demand\n- Technical documentation is well-paying\n- Blog content remains steady\n\nYou could specialize in any niche based on your interests. What type of writing appeals to you?',
  'time': 'Timeline to first client: 1-2 weeks\nTimeline to consistent income: 4-8 weeks\nTimeline to sustainable income: 3-6 months\n\nYou can start with just 10-15 hours/week and scale from there. Many writers earn $500-1000/month part-time.',
  'default': 'That\'s a great question! I\'d be happy to help. Could you be more specific about what you\'d like to know? I can help with:\n\n- Getting started strategies\n- Pricing and rates\n- Marketing yourself\n- Time management\n- Dealing with challenges\n\nWhat would be most helpful?'
}

const suggestedQuestions = [
  { question: 'How do I get started?', key: 'how' },
  { question: 'What skills should I develop?', key: 'skill' },
  { question: 'What are the real startup costs?', key: 'cost' },
  { question: 'What is the market demand?', key: 'market' },
  { question: 'How long to make real money?', key: 'time' }
]

export default function CoachPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '0',
      type: 'coach',
      content: 'Hey! 👋 I\'m your AI Business Coach. I\'m here to help you explore your business opportunity and answer any questions you have about getting started.\n\nWhere would you like to begin?',
      timestamp: new Date()
    }
  ])
  const [input, setInput] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = async (content: string) => {
    if (!content.trim()) return

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content,
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInput('')
    setIsLoading(true)

    // Simulate AI response with delay
    setTimeout(() => {
      const responseKey = Object.keys(mockResponses).find(key =>
        content.toLowerCase().includes(key)
      ) || 'default'

      const coachMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'coach',
        content: mockResponses[responseKey],
        timestamp: new Date()
      }

      setMessages(prev => [...prev, coachMessage])
      setIsLoading(false)
    }, 1000)
  }

  const handleSuggestedQuestion = (question: string) => {
    handleSendMessage(question)
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="font-semibold">BizPath AI Coach</p>
              <p className="text-xs text-muted-foreground">Always here to help</p>
            </div>
          </div>
          <Link href="/dashboard" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
            ← Back to Dashboard
          </Link>
        </div>
      </div>

      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto px-6 lg:px-8 py-8 space-y-6">
          <AnimatePresence>
            {messages.map((message, index) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ delay: index * 0.1 }}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-sm lg:max-w-lg flex gap-3 ${message.type === 'user' ? 'flex-row-reverse' : ''}`}>
                  {message.type === 'coach' && (
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center flex-shrink-0 mt-1">
                      <Zap className="w-4 h-4 text-white" />
                    </div>
                  )}
                  <div
                    className={`p-4 rounded-2xl whitespace-pre-line break-words ${
                      message.type === 'user'
                        ? 'bg-primary text-white'
                        : 'bg-card border border-border text-foreground'
                    }`}
                  >
                    {message.content}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {isLoading && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex justify-start"
            >
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center flex-shrink-0">
                  <Zap className="w-4 h-4 text-white" />
                </div>
                <div className="bg-card border border-border rounded-2xl p-4 flex items-center gap-2">
                  <Loader className="w-4 h-4 animate-spin text-primary" />
                  <span className="text-sm text-muted-foreground">Coach is thinking...</span>
                </div>
              </div>
            </motion.div>
          )}

          {/* Suggested questions shown initially */}
          {messages.length === 1 && !isLoading && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="mt-8"
            >
              <p className="text-sm text-muted-foreground mb-3">Popular questions:</p>
              <div className="grid grid-cols-1 gap-2">
                {suggestedQuestions.map((item, index) => (
                  <motion.button
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.4 + index * 0.1 }}
                    onClick={() => handleSuggestedQuestion(item.question)}
                    className="text-left p-3 rounded-lg border border-border hover:border-primary/50 hover:bg-card/50 transition-all text-sm text-muted-foreground hover:text-foreground"
                  >
                    <div className="flex items-center gap-2">
                      <Lightbulb className="w-4 h-4 text-primary" />
                      {item.question}
                    </div>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input Area */}
      <div className="border-t border-border bg-card/50 backdrop-blur-sm sticky bottom-0">
        <div className="max-w-4xl mx-auto px-6 lg:px-8 py-6">
          <form
            onSubmit={(e) => {
              e.preventDefault()
              handleSendMessage(input)
            }}
            className="flex gap-3"
          >
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask me anything about your business journey..."
              disabled={isLoading}
              className="border-border bg-background"
            />
            <Button
              type="submit"
              disabled={isLoading || !input.trim()}
              size="icon"
              className="bg-primary hover:bg-primary/90 flex-shrink-0"
            >
              <Send className="w-4 h-4" />
            </Button>
          </form>

          {/* Quick actions */}
          <div className="mt-4 flex flex-wrap gap-2">
            <button
              onClick={() => handleSendMessage('Create a detailed marketing plan')}
              className="text-xs px-3 py-1 rounded-full border border-border hover:border-primary/50 text-muted-foreground hover:text-foreground transition-all"
            >
              📱 Marketing Plan
            </button>
            <button
              onClick={() => handleSendMessage('What are common mistakes?')}
              className="text-xs px-3 py-1 rounded-full border border-border hover:border-primary/50 text-muted-foreground hover:text-foreground transition-all"
            >
              ⚠️ Common Mistakes
            </button>
            <button
              onClick={() => handleSendMessage('Generate a pricing strategy')}
              className="text-xs px-3 py-1 rounded-full border border-border hover:border-primary/50 text-muted-foreground hover:text-foreground transition-all"
            >
              💰 Pricing Strategy
            </button>
            <button
              onClick={() => handleSendMessage('How do I find my first clients?')}
              className="text-xs px-3 py-1 rounded-full border border-border hover:border-primary/50 text-muted-foreground hover:text-foreground transition-all"
            >
              👥 Find Clients
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
