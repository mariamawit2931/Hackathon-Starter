'use client'

import Link from 'next/link'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { ArrowRight, Zap, TrendingUp, Sparkles, Target, LineChart } from 'lucide-react'

export default function LandingPage() {
  const features = [
    {
      icon: Sparkles,
      title: 'AI Recommendations',
      description: 'Get personalized business ideas that match your unique profile and constraints.'
    },
    {
      icon: Target,
      title: 'Readiness Score',
      description: 'See exactly how ready you are to start each business with a detailed analysis.'
    },
    {
      icon: LineChart,
      title: 'Skill Gap Analysis',
      description: 'Identify what skills you need to develop and get resources to close the gap.'
    },
    {
      icon: TrendingUp,
      title: 'Local Business Trends',
      description: 'Discover trending opportunities specific to your location and market.'
    },
    {
      icon: Zap,
      title: 'AI Business Coach',
      description: 'Get real-time guidance and support from our intelligent AI assistant.'
    },
  ]

  const businesses = [
    { name: 'Coffee Business', emoji: '☕' },
    { name: 'Digital Marketing', emoji: '📱' },
    { name: 'Online Tutoring', emoji: '📚' },
    { name: 'Freelancing', emoji: '💻' },
    { name: 'Import/Export', emoji: '🚢' },
    { name: 'Content Creation', emoji: '📸' },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="relative px-6 lg:px-8 py-20 lg:py-32 overflow-hidden">
        {/* Animated background gradient */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-20 left-10 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
          <div className="absolute top-1/2 left-1/3 w-72 h-72 bg-secondary/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }}></div>
        </div>

        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-block px-4 py-2 rounded-full border border-primary/30 bg-primary/10 mb-6">
            <p className="text-sm font-medium text-primary">🇪🇹 Built for Ethiopian Founders</p>
          </div>

          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
            Turn Your Degree Into <span className="bg-gradient-to-r from-primary to-primary bg-clip-text text-transparent">a Dynasty</span>
          </h1>

          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            AI Business Architect that turns your capital, skills & passion into a realistic startup roadmap. <span className="text-primary font-semibold">Built for Ethiopian Founders.</span>
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button asChild size="lg" className="bg-primary hover:bg-primary/90 text-white glow-emerald">
              <Link href="/assessment" className="flex items-center gap-2">
                🚀 Start Free Assessment
                <ArrowRight className="w-4 h-4" />
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link href="#how-it-works">See How It Works</Link>
            </Button>
          </div>

          {/* Demo card showcase */}
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-accent/20 rounded-2xl blur-xl"></div>
            <div className="relative bg-card border border-border rounded-2xl p-8 backdrop-blur-sm">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 rounded-lg bg-background/50 border border-border">
                  <p className="text-sm text-muted-foreground">Budget Range</p>
                  <p className="text-lg font-semibold">$5,000 - $25,000</p>
                </div>
                <div className="p-4 rounded-lg bg-background/50 border border-border">
                  <p className="text-sm text-muted-foreground">Readiness Score</p>
                  <p className="text-lg font-semibold text-primary">82%</p>
                </div>
                <div className="p-4 rounded-lg bg-background/50 border border-border">
                  <p className="text-sm text-muted-foreground">Matches Found</p>
                  <p className="text-lg font-semibold text-accent">12+</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="px-6 lg:px-8 py-20 bg-card/30">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Why Choose BizPath AI?</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              AI-powered analysis tailored for Ethiopian entrepreneurs with local market insights.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon
              return (
                <Card key={index} className="p-6 border-border hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/10">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="px-6 lg:px-8 py-20">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">How It Works</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              A simple 4-step process to find your ideal business opportunity.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[
              {
                step: '01',
                title: 'Complete Assessment',
                description: 'Answer questions about your budget, skills, and preferences.'
              },
              {
                step: '02',
                title: 'AI Analysis',
                description: 'Our AI analyzes your profile against thousands of businesses.'
              },
              {
                step: '03',
                title: 'Get Recommendations',
                description: 'Receive personalized business recommendations with readiness scores.'
              },
              {
                step: '04',
                title: 'Create Action Plan',
                description: 'Access detailed roadmaps and resources for your chosen business.'
              }
            ].map((item, index) => (
              <div key={index} className="relative">
                {index < 3 && (
                  <div className="hidden md:block absolute top-16 left-[60%] w-[40%] h-0.5 bg-gradient-to-r from-primary/50 to-transparent"></div>
                )}
                <Card className="p-6 border-border h-full">
                  <div className="text-3xl font-bold text-primary mb-4">{item.step}</div>
                  <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
                  <p className="text-muted-foreground text-sm">{item.description}</p>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trends Section */}
      <section id="trends" className="px-6 lg:px-8 py-20 bg-card/30">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">🇪🇹 Trending in Ethiopian Market</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Hottest business opportunities emerging in Ethiopia right now.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {businesses.map((business, index) => (
              <Card key={index} className="p-6 text-center border-border hover:border-primary/50 transition-all duration-300">
                <div className="text-4xl mb-3">{business.emoji}</div>
                <p className="font-semibold text-sm">{business.name}</p>
              </Card>
            ))}
          </div>

          <div className="mt-12 text-center">
            <Button asChild size="lg" className="bg-primary hover:bg-primary/90">
              <Link href="/assessment">Explore More Opportunities</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
