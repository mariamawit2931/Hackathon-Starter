'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ArrowRight, CheckCircle, AlertCircle, Lightbulb, BookOpen, Clock, Target } from 'lucide-react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'

type BusinessDetailProps = {
  params: {
    id: string
  }
}

const businessDetails: Record<string, any> = {
  '1': {
    name: 'Freelance Writing',
    icon: '✍️',
    matchPercentage: 92,
    readinessScore: 85,
    startupCost: '$500 - $2,000',
    riskLevel: 'Low',
    profitPotential: 'Medium',
    description: 'Leverage your communication skills to build a writing business.',
    overview: 'Start a freelance writing business serving clients across industries. Create content for blogs, websites, marketing materials, and more. This business requires minimal startup costs and can be started from home.',
    materials: [
      'Computer/laptop',
      'Writing software (free options available)',
      'Portfolio website',
      'Time tracking tools'
    ],
    nonMaterials: [
      'Strong writing skills',
      'Research abilities',
      'Time management',
      'Customer communication',
      'Marketing yourself'
    ],
    roadmap: [
      { phase: 'Week 1-2', tasks: ['Set up portfolio', 'Create profiles on freelance platforms', 'Write 3-5 sample pieces'] },
      { phase: 'Week 3-4', tasks: ['Start bidding on projects', 'Apply to job postings', 'Network with other writers'] },
      { phase: 'Month 2', tasks: ['Complete first 5 projects', 'Gather testimonials', 'Refine pricing'] },
      { phase: 'Month 3+', tasks: ['Build recurring client base', 'Raise rates', 'Develop specialization'] }
    ],
    missingSkills: [
      { skill: 'SEO Writing', level: 'Beginner', resources: ['Free SEO courses', 'Practice on medium'] },
      { skill: 'Technical Writing', level: 'Beginner', resources: ['Online tutorials', 'Sample projects'] }
    ],
    resources: [
      { type: 'Platform', name: 'Upwork', url: '#' },
      { type: 'Platform', name: 'Fiverr', url: '#' },
      { type: 'Course', name: 'Writing for the Web', url: '#' },
      { type: 'Tool', name: 'Grammarly', url: '#' }
    ],
    actionPlan: [
      { day: 'Day 1', action: 'Create LinkedIn and portfolio website' },
      { day: 'Day 2-3', action: 'Join 3 freelance platforms and complete profiles' },
      { day: 'Day 4-7', action: 'Write and publish 5 high-quality sample articles' },
      { day: 'Day 8-14', action: 'Start applying to job postings and send cold pitches' },
      { day: 'Day 15-21', action: 'Complete first project and optimize based on feedback' },
      { day: 'Day 22-30', action: 'Land second client and establish workflow' }
    ]
  }
}

export default function BusinessDetailPage({ params }: BusinessDetailProps) {
  const business = businessDetails[params.id]
  const [expandedDay, setExpandedDay] = useState<string | null>(null)

  if (!business) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Business not found</h1>
          <Button asChild>
            <Link href="/dashboard">Back to Dashboard</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="max-w-4xl mx-auto px-6 lg:px-8">
        {/* Header */}
        <Link href="/dashboard" className="text-sm text-muted-foreground hover:text-foreground transition-colors mb-6 inline-flex items-center gap-2">
          ← Back to Recommendations
        </Link>

        <div className="flex items-start gap-6 mb-8">
          <div className="text-6xl">{business.icon}</div>
          <div className="flex-1">
            <h1 className="text-4xl font-bold mb-3">{business.name}</h1>
            <p className="text-lg text-muted-foreground mb-4">{business.description}</p>
            <div className="flex flex-wrap gap-3">
              <Badge variant="default" className="bg-primary">{business.matchPercentage}% Match</Badge>
              <Badge variant="secondary">{business.riskLevel} Risk</Badge>
              <Badge variant="secondary">{business.profitPotential} Profit</Badge>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Startup Cost', value: business.startupCost, icon: '💰' },
            { label: 'Readiness Score', value: `${business.readinessScore}%`, icon: '🎯' },
            { label: 'Time to Launch', value: '2-4 weeks', icon: '⏱️' },
            { label: 'Difficulty Level', value: 'Beginner', icon: '📊' }
          ].map((stat, index) => (
            <Card key={index} className="p-4 border-border">
              <p className="text-sm text-muted-foreground mb-2">{stat.label}</p>
              <p className="text-lg font-bold">{stat.value}</p>
            </Card>
          ))}
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="overview" className="mb-8">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="roadmap">Roadmap</TabsTrigger>
            <TabsTrigger value="skills">Skills Gap</TabsTrigger>
            <TabsTrigger value="resources">Resources</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold mb-4">Business Overview</h2>
              <p className="text-muted-foreground mb-6">{business.overview}</p>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-primary" />
                Material Requirements
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {business.materials.map((item: string, index: number) => (
                  <div key={index} className="flex items-center gap-3 p-3 bg-card rounded-lg border border-border">
                    <div className="w-2 h-2 rounded-full bg-primary"></div>
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Lightbulb className="w-5 h-5 text-accent" />
                Non-Material Requirements
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {business.nonMaterials.map((item: string, index: number) => (
                  <div key={index} className="flex items-center gap-3 p-3 bg-card rounded-lg border border-border">
                    <div className="w-2 h-2 rounded-full bg-accent"></div>
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Roadmap Tab */}
          <TabsContent value="roadmap" className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold mb-4">Startup Roadmap</h2>
              <p className="text-muted-foreground mb-6">Your step-by-step guide to launch this business.</p>
            </div>

            <div className="space-y-4">
              {business.roadmap.map((phase: any, index: number) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="p-6 border-border hover:border-primary/50 transition-all">
                    <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                      <Clock className="w-5 h-5 text-primary" />
                      {phase.phase}
                    </h3>
                    <ul className="space-y-2">
                      {phase.tasks.map((task: string, taskIndex: number) => (
                        <li key={taskIndex} className="flex items-start gap-3 text-muted-foreground">
                          <CheckCircle className="w-4 h-4 mt-1 text-primary flex-shrink-0" />
                          <span>{task}</span>
                        </li>
                      ))}
                    </ul>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Skills Gap Tab */}
          <TabsContent value="skills" className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold mb-4">Skills Gap Analysis</h2>
              <p className="text-muted-foreground mb-6">Skills you might want to develop to excel in this business.</p>
            </div>

            <div className="space-y-4">
              {business.missingSkills.map((skill: any, index: number) => (
                <Card key={index} className="p-6 border-border">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="font-semibold text-lg">{skill.skill}</h3>
                      <p className="text-sm text-muted-foreground">Recommended level: {skill.level}</p>
                    </div>
                    <Badge variant="secondary">{skill.level}</Badge>
                  </div>
                  <div>
                    <p className="text-sm font-medium mb-2">Learning Resources:</p>
                    <ul className="space-y-1">
                      {skill.resources.map((resource: string, idx: number) => (
                        <li key={idx} className="text-sm text-primary hover:underline cursor-pointer">
                          → {resource}
                        </li>
                      ))}
                    </ul>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Resources Tab */}
          <TabsContent value="resources" className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold mb-4">Helpful Resources</h2>
              <p className="text-muted-foreground mb-6">Tools and platforms to help you get started.</p>
            </div>

            <div className="space-y-3">
              {business.resources.map((resource: any, index: number) => (
                <Card key={index} className="p-4 border-border hover:border-primary/50 transition-all cursor-pointer">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">{resource.type}</p>
                      <p className="font-semibold">{resource.name}</p>
                    </div>
                    <ArrowRight className="w-5 h-5 text-primary" />
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* 30-Day Action Plan */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Target className="w-6 h-6 text-primary" />
            Your 30-Day Action Plan
          </h2>

          <div className="space-y-3">
            {business.actionPlan.map((item: any, index: number) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card
                  className="p-4 border-border cursor-pointer hover:border-primary/50 transition-all"
                  onClick={() => setExpandedDay(expandedDay === item.day ? null : item.day)}
                >
                  <div className="flex items-center gap-3">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-sm font-bold text-primary">{index + 1}</span>
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-sm">{item.day}</p>
                      <p className="text-muted-foreground text-sm">{item.action}</p>
                    </div>
                    <CheckCircle className="w-5 h-5 text-muted-foreground" />
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="flex flex-col sm:flex-row gap-4">
          <Button asChild size="lg" className="flex-1 bg-primary hover:bg-primary/90">
            <Link href="/coach">Chat with AI Coach About This</Link>
          </Button>
          <Button asChild variant="outline" size="lg" className="flex-1">
            <Link href="/dashboard">View More Opportunities</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
